-- MySQL dump 10.13  Distrib 5.5.37, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: bikeshopdb
-- ------------------------------------------------------
-- Server version	5.5.37-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `available_bicycles`
--

DROP TABLE IF EXISTS `available_bicycles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `available_bicycles` (
  `id` bigint(20) NOT NULL,
  `availability` tinyint(1) DEFAULT NULL,
  `bicycles_count` int(11) DEFAULT NULL,
  `bicycle_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_an44nl7sgw0hthg5al88jw0` (`bicycle_id`),
  KEY `FK_an44nl7sgw0hthg5al88jw0` (`bicycle_id`),
  CONSTRAINT `FK_an44nl7sgw0hthg5al88jw0` FOREIGN KEY (`bicycle_id`) REFERENCES `bicycles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `available_bicycles`
--

LOCK TABLES `available_bicycles` WRITE;
/*!40000 ALTER TABLE `available_bicycles` DISABLE KEYS */;
INSERT INTO `available_bicycles` VALUES (0,NULL,10,0),(1,NULL,7,1),(2,NULL,15,2),(3,NULL,10,3);
/*!40000 ALTER TABLE `available_bicycles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bicycles`
--

DROP TABLE IF EXISTS `bicycles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bicycles` (
  `id` bigint(20) NOT NULL,
  `brakes` varchar(255) DEFAULT NULL,
  `cassette` varchar(255) DEFAULT NULL,
  `chain` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `crackset` varchar(255) DEFAULT NULL,
  `fork` varchar(255) DEFAULT NULL,
  `fork_move` int(11) DEFAULT NULL,
  `frame_materials` varchar(255) DEFAULT NULL,
  `front_derailer` varchar(255) DEFAULT NULL,
  `guarantee` varchar(255) DEFAULT NULL,
  `handlebar` varchar(255) DEFAULT NULL,
  `lockout` tinyint(1) DEFAULT NULL,
  `manufacturer` varchar(255) NOT NULL,
  `pedals` varchar(255) DEFAULT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `rates_number` tinyint(4) DEFAULT NULL,
  `rear_derailer` varchar(255) DEFAULT NULL,
  `saddle` varchar(255) DEFAULT NULL,
  `shifters` varchar(255) DEFAULT NULL,
  `bicycle_size` varchar(255) NOT NULL,
  `sprockets` varchar(255) DEFAULT NULL,
  `tires` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `weight` double DEFAULT NULL,
  `wheels_diameter` tinyint(4) DEFAULT NULL,
  `year` tinyblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bicycles`
--

LOCK TABLES `bicycles` WRITE;
/*!40000 ALTER TABLE `bicycles` DISABLE KEYS */;
INSERT INTO `bicycles` VALUES (0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Fuji',NULL,'pic/0.png',590,'Traverse 1.3',NULL,NULL,NULL,NULL,'XL',NULL,NULL,'Гибридный',NULL,NULL,NULL),(1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GT',NULL,'pic/1.png',389,'Timberline 2.0',NULL,NULL,NULL,NULL,'M',NULL,NULL,'Горный',NULL,NULL,NULL),(2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GT',NULL,'pic/2.png',499,'Avalanche Sport',NULL,NULL,NULL,NULL,'XL',NULL,NULL,'Горный',NULL,NULL,NULL),(3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Fuji',NULL,'pic/3.png',720,'Traverse 1.1',NULL,NULL,NULL,NULL,'M',NULL,NULL,'Гибридный',NULL,NULL,NULL);
/*!40000 ALTER TABLE `bicycles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL,
  `goods_cost` double NOT NULL,
  `order_date` date NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `products_count` int(11) NOT NULL,
  `bicycle_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_q3pc5qwuyri8snomhqavssmhh` (`bicycle_id`),
  KEY `FK_k8kupdtcdpqd57b6j4yq9uvdj` (`user_id`),
  CONSTRAINT `FK_k8kupdtcdpqd57b6j4yq9uvdj` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FK_q3pc5qwuyri8snomhqavssmhh` FOREIGN KEY (`bicycle_id`) REFERENCES `bicycles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_archive`
--

DROP TABLE IF EXISTS `orders_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders_archive` (
  `id` bigint(20) NOT NULL,
  `goods_cost` double NOT NULL,
  `order_date` date NOT NULL,
  `orders_count` int(11) NOT NULL,
  `bicycle_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_97beet5p210p64odvrtyji5d7` (`bicycle_id`),
  KEY `FK_bj5pakxyx6ujgog09474wcpux` (`user_id`),
  CONSTRAINT `FK_97beet5p210p64odvrtyji5d7` FOREIGN KEY (`bicycle_id`) REFERENCES `bicycles` (`id`),
  CONSTRAINT `FK_bj5pakxyx6ujgog09474wcpux` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_archive`
--

LOCK TABLES `orders_archive` WRITE;
/*!40000 ALTER TABLE `orders_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `user_role` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-06-11 17:04:08
